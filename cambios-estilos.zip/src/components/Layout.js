import React, { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

const Layout = ({ children }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [usuario, setUsuario] = useState(null);

  useEffect(() => {
    const u = localStorage.getItem("usuario");
    if (u) setUsuario(JSON.parse(u));
  }, []);

  const esAdmin = usuario?.rol === 'ADMIN';

  // Los estilos (ios.css / apple.css) dejan espacio para el menú lateral y la barra inferior con esta clase
  useEffect(() => {
    document.body.classList.add('con-tabs');
    return () => document.body.classList.remove('con-tabs');
  }, []);

  const pestana = (to, texto, icono) => {
    const activo = location.pathname === to;
    return (
      <Link to={to} className={activo ? 'activo' : ''} aria-label={texto}>
        <i className={`bi ${icono}${activo ? '-fill' : ''}`}></i><span>{texto}</span>
      </Link>
    );
  };

  const cerrarSesion = () => {
    localStorage.removeItem("jwtToken");
    localStorage.removeItem("usuarioId");
    localStorage.removeItem("usuario");
    navigate('/login');
  };

  const alternarTema = () => {
    const currentTheme = document.documentElement.getAttribute('data-bs-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-bs-theme', newTheme);
    localStorage.setItem('tema', newTheme === 'dark' ? 'oscuro' : 'claro');
  };

  return (
    <div>
      <aside className="sidebar">
        <Link className="sb-brand" to="/">
          <span className="logo"><i className="bi bi-wallet2"></i></span>FinanPlus
        </Link>
        <nav>
          <Link className={`sb-item ${location.pathname === '/' ? 'activo' : ''}`} to="/"><i className="bi bi-house"></i><span>Inicio</span></Link>
          <div className="sb-seccion">Finanzas</div>
          <Link className={`sb-item ${location.pathname === '/registros' ? 'activo' : ''}`} to="/registros"><i className="bi bi-receipt"></i><span>Registros</span></Link>
          <Link className={`sb-item ${location.pathname === '/recurrentes' ? 'activo' : ''}`} to="/recurrentes"><i className="bi bi-arrow-repeat"></i><span>Recurrentes</span></Link>
          <Link className={`sb-item ${location.pathname === '/metas' ? 'activo' : ''}`} to="/metas"><i className="bi bi-bullseye"></i><span>Metas</span></Link>
          <div className="sb-seccion">Organización</div>
          <Link className={`sb-item ${location.pathname === '/categorias' ? 'activo' : ''}`} to="/categorias"><i className="bi bi-folder2"></i><span>Categorías</span></Link>
          <div className="sb-seccion">Análisis</div>
          <Link className={`sb-item ${location.pathname === '/metricas' ? 'activo' : ''}`} to="/metricas"><i className="bi bi-speedometer2"></i><span>Métricas</span></Link>
          <div className="sb-seccion">Cuenta</div>
          <Link className={`sb-item ${location.pathname === '/perfil' ? 'activo' : ''}`} to="/perfil"><i className="bi bi-person-circle"></i><span>Mi perfil</span></Link>
          {esAdmin && <Link className={`sb-item ${location.pathname === '/usuarios' ? 'activo' : ''}`} to="/usuarios"><i className="bi bi-people"></i><span>Usuarios</span></Link>}
        </nav>
        <div className="sb-pie">
          <div className="sb-acciones">
            <button className="btn-tema" type="button" onClick={alternarTema} aria-label="Cambiar entre modo claro y oscuro" title="Modo claro / oscuro">
              <i className="bi bi-moon-stars i-luna"></i><i className="bi bi-sun i-sol"></i>
            </button>
            <button className="btn-salir" type="button" onClick={cerrarSesion}><i className="bi bi-box-arrow-right"></i>Cerrar sesión</button>
          </div>
        </div>
      </aside>
      <main className="container">
        {children}
      </main>
      <nav className="tab-bar" aria-label="Pestañas">
        {pestana('/', 'Inicio', 'bi-house')}
        {pestana('/registros', 'Registros', 'bi-receipt')}
        {pestana('/metas', 'Metas', 'bi-bullseye')}
        {pestana('/metricas', 'Métricas', 'bi-speedometer2')}
        {pestana('/perfil', 'Perfil', 'bi-person-circle')}
      </nav>
    </div>
  );
};

export default Layout;
